TS18 DoFun runtime validation v2

Run tag: v2
Base: /sdcard/Download/ts18_dofun_runtime_validation_v2_20260610_162755

This collector is safe/read-only by default. It uses explicit --user 10177 for am/pm/cmd probes to avoid the user -2 failure seen in v1.

Optional modes:
  INCLUDE_APKS=1          copy readable APKs for com.tw.media/com.tw.music/com.dofun.variety/com.navimods.radio/com.tw.radio
  TRY_DISABLE_STOCK=1    attempt reversible pm disable/hide/suspend of stock com.tw.music
  TRY_UNINSTALL_STOCK=1  with TRY_DISABLE_STOCK=1, also try pm uninstall -k --user 10177 com.tw.music
  RESTORE_STOCK=1        attempt pm enable/unhide/unsuspend/install-existing for com.tw.music
